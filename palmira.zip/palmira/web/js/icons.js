/* Icon set — stroke-based, lucide style */
(function(){
const P = {
  menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',
  back:'<path d="M19 12H5M12 19l-7-7 7-7"/>',
  forward:'<path d="M5 12h14M12 5l7 7-7 7"/>',
  chevR:'<path d="M9 18l6-6-6-6"/>',
  chevD:'<path d="M6 9l6 6 6-6"/>',
  user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  mail:'<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3 7.5l9 6 9-6"/>',
  phone:'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
  lock:'<rect x="3.5" y="11" width="17" height="10.5" rx="2.5"/><path d="M7.5 11V7a4.5 4.5 0 0 1 9 0v4"/>',
  eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff:'<path d="M9.9 9.9a3 3 0 1 0 4.2 4.2M10.7 5.1A10.6 10.6 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-2.2 3.2M6.6 6.6A16.4 16.4 0 0 0 2 12s3.5 7 10 7c1.9 0 3.6-.5 5-1.4"/><path d="M3 3l18 18"/>',
  check:'<path d="M20 6L9 17l-5-5"/>',
  checkC:'<circle cx="12" cy="12" r="9.5"/><path d="M8 12.3l2.6 2.7L16 9"/>',
  grid:'<rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/>',
  search:'<circle cx="11" cy="11" r="7.5"/><path d="M21 21l-4.8-4.8"/>',
  mic:'<rect x="9" y="2.5" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3.5"/>',
  bell:'<path d="M6 8.5a6 6 0 0 1 12 0c0 6.5 2.5 8 2.5 8h-17S6 15 6 8.5"/><path d="M10.3 20.5a1.94 1.94 0 0 0 3.4 0"/>',
  bellFull:'<path fill="currentColor" stroke="none" d="M6 8.5a6 6 0 0 1 12 0c0 6.5 2.5 8 2.5 8h-17S6 15 6 8.5"/><path d="M10.3 20.5a1.94 1.94 0 0 0 3.4 0" fill="currentColor" stroke="none"/>',
  pin:'<path d="M20 10.2c0 5.8-8 11.6-8 11.6s-8-5.8-8-11.6a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
  pinFill:'<path fill="currentColor" stroke="none" d="M20 10.2c0 5.8-8 11.6-8 11.6s-8-5.8-8-11.6a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3" fill="#fff" stroke="none"/>',
  camera:'<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3.4"/>',
  scooter:'<circle cx="5.5" cy="17.5" r="2.6"/><circle cx="18.5" cy="17.5" r="2.6"/><path d="M8.1 17.5h6.4M15.5 5.5h2.2l1 3.2M18.7 8.7a4 4 0 0 1-3.2 4.8l-3.6 4M5.5 14.9V12a1 1 0 0 1 1-1h3.4"/>',
  star:'<path d="M12 2.5l2.9 6.1 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.2 1.2-6.5L2.5 9.5l6.6-.9z"/>',
  chat:'<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5z"/>',
  clock:'<circle cx="12" cy="12" r="9.5"/><path d="M12 6.5V12l3.6 2"/>',
  shield:'<path d="M12 21.5s8-4 8-10V5l-8-3-8 3v6.5c0 6 8 10 8 10z"/><path d="M8.8 11.8l2.3 2.4 4.4-4.6"/>',
  layers:'<path d="M12 2.5L2.5 7.5 12 12.5l9.5-5z"/><path d="M2.5 12l9.5 5 9.5-5M2.5 16.5l9.5 5 9.5-5"/>',
  crosshair:'<circle cx="12" cy="12" r="7.5"/><circle cx="12" cy="12" r="2.4" fill="currentColor" stroke="none"/><path d="M12 1.5v4M12 18.5v4M1.5 12h4M18.5 12h4"/>',
  trash:'<path d="M3.5 6.5h17M8.5 6.5V4.8A1.8 1.8 0 0 1 10.3 3h3.4a1.8 1.8 0 0 1 1.8 1.8v1.7M18.5 6.5V19a2 2 0 0 1-2 2h-9a2 2 0 0 1-2-2V6.5"/><path d="M10 11v6M14 11v6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  minus:'<path d="M5 12h14"/>',
  home:'<path d="M3 9.5l9-7.5 9 7.5V20a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9.5 22v-8.5h5V22"/>',
  clipboard:'<rect x="8" y="2.5" width="8" height="4" rx="1.2"/><path d="M16 4.5h2a2 2 0 0 1 2 2V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6.5a2 2 0 0 1 2-2h2"/><path d="M8.5 11.5h7M8.5 15.5h5"/>',
  heart:'<path d="M20.8 4.9a5.6 5.6 0 0 0-7.8 0L12 5.9l-1-1a5.6 5.6 0 0 0-7.8 7.8l1 1L12 21.2l7.8-7.5 1-1a5.6 5.6 0 0 0 0-7.8z"/>',
  heartFill:'<path fill="currentColor" stroke="none" d="M20.8 4.9a5.6 5.6 0 0 0-7.8 0L12 5.9l-1-1a5.6 5.6 0 0 0-7.8 7.8l1 1L12 21.2l7.8-7.5 1-1a5.6 5.6 0 0 0 0-7.8z"/>',
  card:'<rect x="2.5" y="5" width="19" height="14" rx="2.5"/><path d="M2.5 9.5h19"/><path d="M6 15h4"/>',
  building:'<rect x="4.5" y="3" width="15" height="18" rx="1.5"/><path d="M9 7.5h1.6M13.4 7.5H15M9 11.5h1.6M13.4 11.5H15M9 15.5h1.6M13.4 15.5H15M10 21v-3h4v3"/>',
  nav:'<path d="M3 11l19-9-9 19-2-8-8-2z"/>',
  info:'<circle cx="12" cy="12" r="9.5"/><path d="M12 11v5.5M12 7.5h.01"/>',
  x:'<path d="M18 6L6 18M6 6l12 12"/>',
  logout:'<path d="M9 21H5.5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2H9"/><path d="M16 17l5-5-5-5M21 12H9"/>',
  help:'<circle cx="12" cy="12" r="9.5"/><path d="M9.2 9a2.9 2.9 0 0 1 5.6 1c0 1.9-2.8 2.6-2.8 4M12 17.2h.01"/>',
  settings:'<circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.9 2.9l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.2a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.9-2.9l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.2A1.7 1.7 0 0 0 4.7 8.6a1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.9-2.9l.1.1a1.7 1.7 0 0 0 1.9.3h.1a1.7 1.7 0 0 0 1-1.5V2.5a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 1 1.5h.1a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.9 2.9l-.1.1a1.7 1.7 0 0 0-.3 1.9v.1a1.7 1.7 0 0 0 1.5 1h.2a2 2 0 1 1 0 4h-.2a1.7 1.7 0 0 0-1.5 1z"/>',
  refresh:'<path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15"/>',
  zap:'<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>',
  wallet:'<rect x="2.5" y="6" width="19" height="14" rx="2.5"/><path d="M2.5 10h19M16.5 15h.01"/><path d="M6.5 6V4.8A1.8 1.8 0 0 1 8.3 3h8.4"/>',
  image:'<rect x="3" y="3" width="18" height="18" rx="2.5"/><circle cx="8.7" cy="8.7" r="1.7"/><path d="M21 15.5l-5-5L5 21"/>',
  edit:'<path d="M17 3.5a2.4 2.4 0 0 1 3.4 3.4L8 19.3l-4.5 1.2L4.7 16z"/>',
  send:'<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>',
  globe:'<circle cx="12" cy="12" r="9.5"/><path d="M2.5 12h19M12 2.5c2.5 2.7 3.8 6 3.8 9.5s-1.3 6.8-3.8 9.5c-2.5-2.7-3.8-6-3.8-9.5s1.3-6.8 3.8-9.5z"/>',
  gift:'<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M5 12v8a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 20v-8M12 8v13.5M12 8s-4.5.3-5.5-2C5.8 4.5 7 3 8.5 3 11 3 12 8 12 8zm0 0s4.5.3 5.5-2C18.2 4.5 17 3 15.5 3 13 3 12 8 12 8z"/>',
  doc:'<path d="M14 2.5H6.5A1.5 1.5 0 0 0 5 4v16a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 20V7.5z"/><path d="M14 2.5V7.5H19M9 12h6M9 16h6"/>',
  flag:'<path d="M4 22V4.5A1.5 1.5 0 0 1 5.5 3H20l-2.5 5L20 13H6.5"/>'
};
window.I = function(name, size, cls){
  size = size || 22;
  const fillIcons = {star:'fill', heartFill:'fill', pinFill:'fill'};
  let body = P[name] || '';
  const fill = (fillIcons[name]==='fill') ? 'fill="currentColor" stroke="none"' : 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
  return '<svg class="'+(cls||'')+'" width="'+size+'" height="'+size+'" viewBox="0 0 24 24" ' + fill + ' aria-hidden="true">' + body + '</svg>';
};
window.I.fill = function(name, size, cls, color){
  const body = P[name] || '';
  return '<svg class="'+(cls||'')+'" width="'+size+'" height="'+size+'" viewBox="0 0 24 24" fill="'+(color||'currentColor')+'" aria-hidden="true">' + body + '</svg>';
};
})();
