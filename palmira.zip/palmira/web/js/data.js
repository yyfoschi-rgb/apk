/* Palmira Entregas — data */
window.DATA = (function(){
const CATEGORIES = [
  {id:'almacen',  name:'Almacén Despensa',   sub:''},
  {id:'bebidas',  name:'Bebidas',            sub:'(No alcohólicas)'},
  {id:'panaderia',name:'Panadería',          sub:'Envasados'},
  {id:'limpieza', name:'Limpieza',           sub:'Higiene'},
  {id:'farmacia', name:'Farmacia',           sub:''},
  {id:'mascotas', name:'Mascotas',           sub:''},
  {id:'perfumeria',name:'Perfumería',        sub:'Cuidado personal'},
  {id:'libreria', name:'Librería',           sub:'Papelería'},
  {id:'tecnologia',name:'Tecnología',        sub:'Accesorios'},
  {id:'hogar',    name:'Hogar',              sub:'Ferretería'},
  {id:'automotor',name:'Automotor',          sub:'Accesorios'},
  {id:'otros',    name:'Otros',              sub:'Comercios'}
];

const STORE_META = {
  almacen:   {name:'Almacén Despensa', desc:'Productos de almacén, envasados y no perecederos. Elegí lo que necesitás, sin precios.', sub:'Productos de almacén y artículos generales.'},
  bebidas:   {name:'Bebidas', desc:'Bebidas gaseosas, aguas, jugos e isotónicas. Sin alcohol.', sub:'Bebidas no alcohólicas y aguas.'},
  panaderia: {name:'Panadería Envasados', desc:'Galletitas, medialunas y panificados envasados.', sub:'Panificados y galletitas.'},
  limpieza:  {name:'Limpieza y Higiene', desc:'Detergentes, jabones, papel y productos de higiene.', sub:'Limpieza e higiene del hogar.'},
  farmacia:  {name:'Farmacia', desc:'Medicamentos, vitaminas y productos de farmacia.', sub:'Productos de farmacia.'},
  mascotas:  {name:'Mascotas', desc:'Alimento, premios y artículos para tu mascota.', sub:'Todo para tu mascota.'},
  perfumeria:{name:'Perfumería', desc:'Perfumes, cuidado personal y dental.', sub:'Cuidado personal y perfumería.'},
  libreria:  {name:'Librería y Papelería', desc:'Cuadernos, útiles y artículos de papelería.', sub:'Papelería y útiles.'},
  tecnologia:{name:'Tecnología y Accesorios', desc:'Cables, cargadores y accesorios tech.', sub:'Tecnología y accesorios.'},
  hogar:     {name:'Hogar y Ferretería', desc:'Focos, herramientas y ferretería.', sub:'Hogar y ferretería.'},
  automotor: {name:'Automotor', desc:'Aceites, insumos y accesorios automotores.', sub:'Insumos automotores.'},
  otros:     {name:'Otros Comercios', desc:'Decilós qué comercio querés y el rider lo compra por vos.', sub:'Cualquier comercio de la zona.'}
};

function P(id, name, size, sub, price, art){ return {id, name, size, sub, price, art}; }

const ALMACEN = [
  P('agua','Agua mineral','1,5 L','bebidas',1200,'agua'),
  P('gaseosas','Gaseosas','surtido 2 L','bebidas',6500,'gaseosas'),
  P('papas','Papas fritas','170 g','snacks',850,'papas'),
  P('snacks','Snacks','cereal 90 g','snacks',900,'snacks'),
  P('galletas','Galletas','caja','galletas',2400,'galletas'),
  P('bizcochos','Bizcochos','pack','galletas',2200,'bizcochos'),
  P('azucar','Azúcar','1 kg','conservas',1400,'azucar'),
  P('yerba','Yerba mate','1 kg','conservas',5600,'yerba'),
  P('cafe','Café','tostado 500 g','conservas',6800,'cafe'),
  P('te','Té','caja 100 saquitos','conservas',1900,'te'),
  P('harina','Harina','000 1 kg','conservas',1100,'harina'),
  P('arroz','Arroz','grano fino 1 kg','conservas',1300,'arroz'),
  P('lentejas','Lentejas','400 g','conservas',950,'lentejas'),
  P('tomate','Tomate en lata','400 g','conservas',1100,'tomate'),
  P('atun','Atún en lata','170 g','conservas',1800,'atun'),
  P('aceite','Aceite','girasol 1 L','conservas',2600,'aceite'),
  P('sal','Sal','1 kg','conservas',800,'sal'),
  P('panales','Pañales','talla 5 x30','lacteos',14500,'panales'),
  P('alimento','Alimento Mascotas','perro 1 kg','lacteos',3900,'alimento'),
  P('papel','Papel higiénico','4 rollos','lacteos',1300,'papel')
];

const OTHER = {
  bebidas:[
    P('b-agua','Agua mineral','1,5 L','',1200,'agua'),
    P('b-agua5','Agua mineral','5 L','',3200,'agua'),
    P('b-gas','Gaseosas','surtido 2 L','',6500,'gaseosas'),
    P('b-limonada','Limonada','750 ml','',900,'gaseosas'),
    P('b-isotonica','Isotónica','sabor a elegir 500 ml','',700,'gaseosas'),
    P('b-teg','Té gaseado','limón 2 L','',1600,'te')
  ],
  panaderia:[
    P('p-medialunas','Medialunas','docena envasada','',3800,'bizcochos'),
    P('p-vien','Vien pasados','pack 8 unidades','',3200,'bizcochos'),
    P('p-galletitas','Galletitas surtidas','caja','',2400,'galletas'),
    P('p-sandwitch','Pan de sandwitch','1 kg','',1800,'galletas'),
    P('p-panam','Pan amasado','500 g','',1200,'galletas')
  ],
  limpieza:[
    P('l-detergente','Detergente líquido','2,5 L','',4200,'limpieza'),
    P('l-jabon','Jabón en polvo','1 kg','',2800,'limpieza'),
    P('l-agua','Agua sanitizadora','1 L','',700,'limpieza'),
    P('l-lavavajillas','Lavavajillas','1 L','',1900,'limpieza'),
    P('l-papel','Papel higiénico','12 rollos','',3600,'papel')
  ],
  farmacia:[
    P('f-antibiotico','Antibiótico','amoxicilina 500 mg (con receta)','','18000','farmacia'),
    P('f-analgesico','Analgésico','para el dolor de cabeza','',2400,'farmacia'),
    P('f-antipiretico','Antipirético','para adultos','',2600,'farmacia'),
    P('f-vitc','Vitamina C','500 mg x30 comprimidos','',6800,'farmacia'),
    P('f-alcohol','Alcohol en gel','500 ml','',2900,'farmacia'),
    P('f-tiritas','Tiritas','x20 unidades','',900,'farmacia')
  ],
  mascotas:[
    P('m-perro','Alimento perro','adulto 3 kg','',9800,'alimento'),
    P('m-gato','Alimento gato','adulto 1,5 kg','',7900,'alimento'),
    P('m-puro','Premios','pack 100 g','',1400,'alimento'),
    P('m-arena','Arena para gatos','4 kg','',5200,'alimento'),
    P('m-pasteur','Pasteurizadas','12 unidades','',1200,'papel')
  ],
  perfumeria:[
    P('pr-antitrans','Antitranspirante','unisex 50 ml','',4200,'perfumeria'),
    P('pr-pasta','Pasta dental','75 ml','',1800,'perfumeria'),
    P('pr-cepillo','Cepillo dental','suave x2','',1200,'perfumeria'),
    P('pr-jabon','Jabón de tocador','x3 unidades','',1500,'perfumeria'),
    P('pr-perfume','Perfume','unisex 100 ml','',18500,'perfumeria')
  ],
  libreria:[
    P('li-cuadernos','Cuadernos','bolsillo 200 hojas x2','',2400,'libreria'),
    P('li-archivos','Archivos','A4 x10 unidades','',4800,'libreria'),
    P('li-bollos','Bolígrafos','azul x10 unidades','',2200,'libreria'),
    P('li-marca','Marcadores','x6 colores','',3400,'libreria'),
    P('li-precios','Resma A4','80 gr x500 hojas','',6900,'libreria')
  ],
  tecnologia:[
    P('t-cable','Cable USB-C','1,5 m','',2900,'tecnologia'),
    P('t-battery','Batería externa','10.000 mAh','',14800,'tecnologia'),
    P('t-audifonos','Audífonos','Bluetooth','',9900,'tecnologia'),
    P('t-cargador','Cargador rápido','20 W','',3800,'tecnologia'),
    P('t-ramas','Ramas USB','4 puertos','',4500,'tecnologia')
  ],
  hogar:[
    P('h-foco','Foco LED','A60 9 W x2','',1900,'hogar'),
    P('h-tornillos','Tornillos surtidos','bolsa','',1400,'hogar'),
    P('h-cinta','Cinta adhesiva','48 mm x3 unidades','',1600,'hogar'),
    P('h-destornillador','Destornillador','combo 4 piezas','',4200,'hogar'),
    P('h-lampara','Lámpara de escritorio','LED','',6800,'hogar')
  ],
  automotor:[
    P('a-aceite','Aceite de motor','10W40 1 L x4','',9800,'automotor'),
    P('a-filtro','Filtro de aire','según modelo','',4800,'automotor'),
    P('a-lavado','Lavado de auto','estación zona','',9000,'automotor'),
    P('a-bateria','Batería','12V 50Ah','',38500,'automotor'),
    P('a-cinta','Cinta de doble cara','automotriz','',1200,'automotor')
  ],
  otros:[]
};

const CHIPS = {
  almacen:[
    {id:'todos', label:'Todos', icon:'grid'},
    {id:'bebidas', label:'Bebidas', icon:'zap'},
    {id:'snacks', label:'Snacks', icon:'zap'},
    {id:'galletas', label:'Galletas', icon:'zap'},
    {id:'conservas', label:'Conservas', icon:'zap'},
    {id:'lacteos', label:'Lácteos', icon:'zap'}
  ]
};

function productsFor(cat){
  if(cat==='almacen') return ALMACEN;
  return OTHER[cat] || [];
}
function productById(cat, id){
  const list = cat==='almacen' ? ALMACEN : (OTHER[cat]||[]);
  return list.find(p=>p.id===id) || ALMACEN.find(p=>p.id===id);
}
function fmt(n){ return '$ ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g,'.'); }

return {CATEGORIES, STORE_META, productsFor, productById, fmt, RIDER:{name:'Juan', rating:4.9, deliveries:127, phone:'11 2345 6789'}};
})();
