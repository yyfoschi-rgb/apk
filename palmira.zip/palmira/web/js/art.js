/* Palmira Entregas — vector art */
(function(){
const A = {};

/* ---------- P logo mark ---------- */
function pMark(w){
  w = w || 64;
  return `<svg width="${w}" height="${w*0.72}" viewBox="0 0 100 72" fill="none">
  <defs>
    <linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#3ECBF5"/><stop offset=".55" stop-color="#1484FF"/><stop offset="1" stop-color="#0A55E8"/>
    </linearGradient>
  </defs>
  <rect x="4"  y="16" width="26" height="9" rx="4.5" fill="#3ECBF5" opacity=".95"/>
  <rect x="0"  y="30" width="34" height="9" rx="4.5" fill="#29A9F2"/>
  <rect x="4"  y="44" width="26" height="9" rx="4.5" fill="#1484FF" opacity=".95"/>
  <path d="M52 62V16a1 1 0 0 1 1-1h6a21 21 0 0 1 0 42h-2" stroke="url(#pg)" stroke-width="15" stroke-linecap="round"/>
  <g>
    <path d="M44.5 33.5h19l-2.2 16a3.5 3.5 0 0 1-3.5 3h-7.6a3.5 3.5 0 0 1-3.5-3z" fill="#101740"/>
    <path d="M49.5 33.5v-2.2a5 5 0 0 1 10 0v2.2" stroke="#101740" stroke-width="2.6" fill="none"/>
  </g>
</svg>`;
}

/* ---------- full wordmark ---------- */
function logo(h, light){
  h = h || 62;
  const ink = light ? '#FFFFFF' : '#111741';
  return `<div class="brand-mark" style="display:flex;align-items:center;gap:7px">
    ${pMark(h*0.92)}
    <div style="line-height:1">
      <div style="font-family:'Baloo 2';font-weight:800;font-size:${h*0.72}px;color:${ink};letter-spacing:-.5px">Palmira</div>
      <div style="font-family:'Baloo 2';font-weight:700;font-size:${h*0.34}px;color:#2FA8E8;letter-spacing:${h*0.145}px;margin-top:-2px">ENTREGAS</div>
    </div>
  </div>`;
}

/* ---------- water tower (reusable) ---------- */
function tower(x, y, s, col){
  col = col || {tank:'#1D4FA8', roof:'#16386E', txt:'#FFFFFF'};
  return `<g transform="translate(${x},${y}) scale(${s})">
    <path d="M-16 0 L-9 -46 M16 0 L9 -46 M-12 0 L12 -46 M12 0 L-12 -46" stroke="${col.tank}" stroke-width="2.6" stroke-linecap="round"/>
    <rect x="-14" y="-74" width="28" height="30" rx="3" fill="${col.tank}"/>
    <rect x="-14" y="-60" width="28" height="5" fill="rgba(255,255,255,.25)"/>
    <path d="M-17 -74 L0 -92 L17 -74 Z" fill="${col.roof}"/>
    <rect x="-1" y="-98" width="2" height="7" fill="${col.roof}"/>
    <text x="0" y="-52" text-anchor="middle" font-family="Nunito,Arial" font-size="7.4" font-weight="800" fill="${col.txt}" letter-spacing=".4">PALMIRA</text>
  </g>`;
}

/* ---------- auth header: town panorama ---------- */
function townHeader(){
  return `<svg class="hero-art" viewBox="0 0 430 208" preserveAspectRatio="xMidYMax slice">
  <defs>
    <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#D5E9FC"/><stop offset="1" stop-color="#F0F7FF"/>
    </linearGradient>
  </defs>
  <rect width="430" height="208" fill="url(#sky)"/>
  <path d="M0 118 L40 78 L78 112 L120 70 L160 114 L205 84 L250 118 L300 76 L345 116 L395 88 L430 118 V208 H0 Z" fill="#C4DAF4"/>
  <path d="M0 134 L55 96 L105 130 L170 92 L235 132 L300 100 L365 132 L430 104 V208 H0 Z" fill="#A9C9EF"/>
  <g fill="#8FB4E4">
    <rect x="52" y="102" width="16" height="26" rx="2"/>
    <rect x="74" y="108" width="13" height="20" rx="2"/>
    <path d="M52 102 l8 -9 8 9 z"/>
    <rect x="95" y="100" width="5" height="28"/>
    <path d="M92 100 h11 l-5.5 -16 z"/>
    <rect x="106" y="106" width="14" height="22" rx="2"/>
    <path d="M106 106 l7 -8 7 8 z"/>
    <rect x="126" y="110" width="12" height="18" rx="2"/>
    <rect x="250" y="106" width="15" height="22" rx="2"/>
    <path d="M250 106 l7.5 -8 7.5 8 z"/>
    <rect x="270" y="110" width="12" height="18" rx="2"/>
  </g>
  <g fill="#9CC0E8">
    <path d="M20 128 l6 -14 6 14 z"/><path d="M31 128 l5.5 -12 5.5 12 z"/>
    <path d="M150 126 l6 -14 6 14 z"/><path d="M161 126 l5 -11 5 11 z"/>
    <path d="M215 128 l6 -14 6 14 z"/><path d="M320 126 l6 -14 6 14 z"/><path d="M331 126 l5 -11 5 11 z"/>
    <path d="M395 128 l6 -14 6 14 z"/>
  </g>
  ${tower(368, 150, 1.05, {tank:'#4A7FD4', roof:'#3D6CB8', txt:'#FFFFFF'})}
  <path d="M0 150 C 60 132, 120 168, 190 152 S 330 136, 430 156 V208 H0 Z" fill="#8FC6F6"/>
  <path d="M0 166 C 70 146, 150 184, 235 166 S 360 150, 430 170 V208 H0 Z" fill="#1470FF"/>
  <path d="M0 182 C 80 168, 160 198, 250 184 S 380 172, 430 186 V208 H0 Z" fill="#0A5AE8"/>
</svg>`;
}

/* ---------- home hero: scenic Palmira ---------- */
function homeHero(){
  return `<svg class="hero-art" viewBox="0 0 430 212" preserveAspectRatio="xMidYMax slice">
  <defs>
    <linearGradient id="hsky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#9FD4FF"/><stop offset=".6" stop-color="#D8F0FF"/><stop offset="1" stop-color="#EAF8FF"/>
    </linearGradient>
  </defs>
  <rect width="430" height="212" fill="url(#hsky)"/>
  <circle cx="70" cy="40" r="26" fill="#FFF6D8" opacity=".85"/>
  <path d="M0 118 L52 62 L96 104 L150 50 L210 108 L262 66 L318 112 L372 70 L430 116 V212 H0 Z" fill="#A9C7E9"/>
  <path d="M40 76 L52 62 L64 77 L58 72 L46 73 Z M138 64 L150 50 L163 66 L155 60 L145 61 Z M360 84 L372 70 L384 85 L376 79 L367 80 Z" fill="#FFFFFF"/>
  <path d="M0 140 L70 96 L130 136 L200 92 L268 138 L330 100 L430 142 V212 H0 Z" fill="#8FB2DD"/>
  <path d="M0 158 H430 V212 H0 Z" fill="#8CC17E"/>
  <path d="M0 158 C 90 150, 300 166, 430 156 V212 H0 Z" fill="#7DB56F"/>
  <g fill="#2F7A4D">
    <path d="M28 158 l9 -26 9 26 z M52 160 l8 -22 8 22 z M340 158 l9 -26 9 26 z M366 160 l8 -22 8 22 z M392 158 l9 -25 9 25 z"/>
  </g>
  <g fill="#3E9160">
    <path d="M74 160 l8 -22 8 22 z M316 160 l8 -22 8 22 z M34 164 l6 -16 6 16 z M386 164 l6 -16 6 16 z"/>
  </g>
  <rect x="96" y="132" width="26" height="18" rx="2" fill="#DCE7F5"/>
  <path d="M94 132 l15 -11 15 11 z" fill="#5A719B"/>
  <rect x="300" y="134" width="24" height="16" rx="2" fill="#E4EDF8"/>
  <path d="M298 134 l14 -10 14 10 z" fill="#64809F"/>
  <path d="M196 212 L214 148 L222 148 L248 212 Z" fill="#B8C2CF"/>
  <path d="M221 152 L222.5 212 L219.5 212 L220.5 152 Z" fill="#FFFFFF" opacity=".85"/>
  ${tower(352, 176, 1.35, {tank:'#16386E', roof:'#0F2B56', txt:'#FFFFFF'})}
</svg>`;
}

/* ---------- base map (street grid) ---------- */
function mapBase(){
  let h = '';
  const rot = -7;
  const v = 60, hgt = 620, w = 470;
  let roads = '';
  for(let y=-80; y<hgt+80; y+=74){
    const big = (Math.round(y/74) % 3 === 0);
    roads += `<rect x="-90" y="${y-5}" width="${w+180}" height="${big?11:7}" fill="#FFFFFF"/>`;
  }
  for(let x=-90; x<w+120; x+=78){
    const big = (Math.round(x/78) % 3 === 0);
    roads += `<rect x="${x-5}" y="-80" width="${big?11:7}" height="${hgt+160}" fill="#FFFFFF"/>`;
  }
  const parks = `
    <rect x="60" y="120" width="90" height="70" rx="10" fill="#CDE8C4"/>
    <rect x="330" y="60" width="80" height="60" rx="10" fill="#CDE8C4"/>
    <rect x="240" y="330" width="110" height="80" rx="12" fill="#C9E4BF"/>
    <rect x="40" y="420" width="120" height="90" rx="12" fill="#CDE8C4"/>
    <rect x="350" y="470" width="90" height="70" rx="10" fill="#C9E4BF"/>
    <rect x="170" y="520" width="80" height="60" rx="10" fill="#CDE8C4"/>`;
  return `<svg class="map-svg" viewBox="0 0 ${w} ${hgt}" preserveAspectRatio="xMidYMid slice">
    <rect width="${w}" height="${hgt}" fill="#F3F5F0"/>
    <g transform="rotate(${rot} 235 310)">
      ${parks}${roads}
      <g fill="#EDEFE9">
        <rect x="-90" y="-80" width="${w+180}" height="${hgt+160}" fill="none"/>
      </g>
    </g>
  </svg>`;
}

/* ---------- rider avatar ---------- */
function riderAva(sz){
  sz = sz || 56;
  return `<svg width="${sz}" height="${sz}" viewBox="0 0 64 64">
    <circle cx="32" cy="32" r="31" fill="#E3EEFC"/>
    <path d="M12 58c1-12 9-18 20-18s19 6 20 18z" fill="#1470FF"/>
    <path d="M18 58c1-9 7-14 14-14s13 5 14 14z" fill="#0F5FE0"/>
    <rect x="24" y="18" width="16" height="16" rx="7" fill="#F6D7BC"/>
    <path d="M19 26c0-9 6-14 13-14s13 5 13 14v2H19z" fill="#1470FF"/>
    <path d="M19 24h26v5c0 1.6-1.3 3-3 3H22c-1.7 0-3-1.4-3-3z" fill="#EAF3FF"/>
    <path d="M22 33h20v3.4c0 4-4.5 6.6-10 6.6s-10-2.6-10-6.6z" fill="#1E2A55"/>
    <rect x="29" y="12.5" width="6" height="4" rx="1.6" fill="#EAF3FF"/>
  </svg>`;
}

/* ---------- rider shopping (big illo) ---------- */
function riderShop(sz){
  sz = sz || 120;
  return `<svg width="${sz}" height="${sz}" viewBox="0 0 120 120">
    <g transform="translate(0,6)">
      <path d="M18 116c2-26 18-38 42-38s40 12 42 38z" fill="#1470FF"/>
      <path d="M30 116c2-19 13-28 30-28s28 9 30 28z" fill="#0F5FE0"/>
      <rect x="45" y="26" width="30" height="30" rx="13" fill="#F6D7BC"/>
      <path d="M36 44c0-17 11-26 24-26s24 9 24 26v4H36z" fill="#1470FF"/>
      <path d="M36 41h48v9c0 3-2.5 5.6-5.6 5.6H41.6C38.5 55.6 36 53 36 50z" fill="#EAF3FF"/>
      <path d="M42 55h36v6.5c0 7.4-8.2 12.4-18 12.4S42 68.9 42 61.5z" fill="#1E2A55"/>
      <rect x="55" y="14.5" width="10" height="7" rx="2.4" fill="#EAF3FF"/>
      <g>
        <rect x="58" y="74" width="46" height="34" rx="5" fill="#FFFFFF" stroke="#C9D8EF" stroke-width="2.5"/>
        <rect x="52" y="70" width="58" height="8" rx="4" fill="#E3EEFC" stroke="#C9D8EF" stroke-width="2"/>
        <path d="M64 84c-5 0-8-4-6.6-8.4C58.8 71 63 70 65 73.4c2-3.4 6.2-2.4 7.2 2.2C73.6 80 70 84 64 84z" fill="#FF5A5A"/>
        <rect x="70" y="76" width="7" height="18" rx="3.4" fill="#FFB63C"/>
        <rect x="79" y="74" width="7" height="20" rx="3.4" fill="#4CC3FF"/>
        <rect x="88" y="78" width="10" height="16" rx="2.6" fill="#FFD23C"/>
      </g>
    </g>
  </svg>`;
}

/* ---------- generic product helper ---------- */
function P120(inner){ return `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">${inner}</svg>`; }
function txt(x, y, s, size, fill, weight, extra){
  return `<text x="${x}" y="${y}" text-anchor="middle" font-family="Nunito,Arial" font-size="${size}" font-weight="${weight||800}" fill="${fill||'#FFFFFF'}" ${extra||''}>${s}</text>`;
}

/* ---------- product illustrations ---------- */
const PRODUCTS = {
  agua: P120(`<rect x="46" y="30" width="28" height="64" rx="12" fill="#DFF0FF" stroke="#BBDFFC" stroke-width="2"/>
    <rect x="46" y="52" width="28" height="26" fill="#2F8FE0"/>
    ${txt(60,68,'Agua',11,'#fff')}${txt(60,79,'mineral',8,'#DCEFFF',700)}
    <rect x="52" y="22" width="16" height="10" rx="3" fill="#1470FF"/>
    <path d="M52 44c6-4 10 4 16 0" stroke="#BFE3FF" stroke-width="2.4" fill="none"/>`),
  gaseosas: P120(`<g>
    <rect x="18" y="34" width="22" height="58" rx="7" fill="#E3342F"/><rect x="18" y="54" width="22" height="16" fill="#fff"/><path d="M20 62c4 5 12-5 18 0" stroke="#E3342F" stroke-width="2.6" fill="none"/><rect x="23" y="27" width="12" height="8" rx="2.4" fill="#E3342F"/>
    <rect x="46" y="30" width="24" height="62" rx="8" fill="#3FAE5A"/><rect x="46" y="52" width="24" height="17" fill="#E9FBEE"/><path d="M48 60c5 6 13-6 20 0" stroke="#3FAE5A" stroke-width="2.8" fill="none"/><rect x="52" y="23" width="12" height="8" rx="2.4" fill="#2E8B47"/>
    <rect x="76" y="34" width="24" height="58" rx="8" fill="#FF9A3C"/><rect x="76" y="54" width="24" height="17" fill="#FFF3E4"/><circle cx="88" cy="62.5" r="5.5" fill="#FFB63C"/><rect x="82" y="27" width="12" height="8" rx="2.4" fill="#E07C1F"/>
  </g>`),
  papas: P120(`<path d="M38 30 h44 c6 0 8 6 6 11 l-7 46 c-1 6-5 9-11 9 H47 c-6 0-10-3-11-9 l-7-46 c-2-5 0-11 6-11 z" fill="#FFD23C"/>
    <path d="M38 34 c14 -5 30 -5 44 0 l-2 8 c-12 -4 -28 -4 -40 0 z" fill="#FFB92E"/>
    <rect x="40" y="56" width="40" height="22" rx="11" fill="#E23B32"/>
    ${txt(60,72,'Fritas',13,'#fff')}
    <path d="M50 88c4-3 8 2 12-1s8 1 10-1" stroke="#E8A50E" stroke-width="2" fill="none" opacity=".7"/>`),
  snacks: P120(`<path d="M36 28 h48 l4 12 -10 50 c-1 5-5 8-10 8 H52 c-5 0-9-3-10-8 L32 40 z" fill="#E23B32"/>
    <path d="M36 28 h48 l3 9 H33 z" fill="#C22B23"/>
    <rect x="42" y="52" width="36" height="24" rx="4" fill="#FFD23C"/>
    ${txt(60,69,'Snacks',12.5,'#C22B23')}
    <path d="M52 40 l6 8 h-12 z M66 40 l6 8 h-12 z M78 41 l5 7 h-10 z" fill="#FFD23C" opacity=".9"/>`),
  galletas: P120(`<rect x="26" y="60" width="52" height="34" rx="4" fill="#F7E3C0" stroke="#E4C896" stroke-width="2"/>
    <circle cx="40" cy="72" r="4" fill="#D9A85F"/><circle cx="52" cy="78" r="4" fill="#D9A85F"/><circle cx="66" cy="71" r="4" fill="#D9A85F"/><circle cx="70" cy="82" r="3.4" fill="#D9A85F"/>
    <rect x="34" y="40" width="52" height="26" rx="4" fill="#FFFFFF" stroke="#E4C896" stroke-width="2"/>
    <rect x="34" y="40" width="52" height="9" fill="#5FB3E0"/>
    ${txt(60,63,'Galletas',10.5,'#5FB3E0')}
    <circle cx="44" cy="32" r="7" fill="#E8B96B"/><circle cx="42" cy="30" r="1" fill="#B07E35"/><circle cx="46" cy="34" r="1" fill="#B07E35"/><circle cx="58" cy="28" r="6" fill="#E8B96B"/><circle cx="57" cy="26" r="1" fill="#B07E35"/><circle cx="61" cy="30" r="1" fill="#B07E35"/>`),
  bizcochos: P120(`<rect x="30" y="62" width="44" height="30" rx="4" fill="#FFF" stroke="#D9B98C" stroke-width="2"/>
    <rect x="30" y="62" width="44" height="10" fill="#E2574C"/>
    ${txt(52,84,'Bizcochos',8.6,'#B07E35')}
    <g><circle cx="82" cy="42" r="9" fill="#E8B96B"/><circle cx="80" cy="40" r="1.2" fill="#A97430"/><circle cx="85" cy="45" r="1.2" fill="#A97430"/><circle cx="90" cy="58" r="8" fill="#E8B96B"/><circle cx="88" cy="56" r="1.1" fill="#A97430"/><circle cx="93" cy="61" r="1.1" fill="#A97430"/><circle cx="78" cy="62" r="7" fill="#E8B96B"/></g>`),
  azucar: P120(`<rect x="34" y="34" width="52" height="60" rx="7" fill="#FFFFFF" stroke="#D5DEEC" stroke-width="2"/>
    <path d="M34 46 l26 -8 26 8 v-6 a6 6 0 0 0-6-6 H40 a6 6 0 0 0-6 6 z" fill="#1B66C9"/>
    <rect x="34" y="50" width="52" height="12" fill="#1B66C9"/>
    ${txt(60,59.5,'Azúcar',10,'#fff')}
    <circle cx="60" cy="80" r="11" fill="#EAF3FF"/>
    <path d="M54 78 l6 -5 6 5 -2 7 h-8 z" fill="#9CC4F0"/>`),
  yerba: P120(`<path d="M40 26 h40 l6 10 -6 58 H40 l-6 -58 z" fill="#FFD23C"/>
    <rect x="34" y="46" width="52" height="16" fill="#2E8B47"/>
    ${txt(60,58,'Yerba mate',10,'#fff')}
    <circle cx="60" cy="76" r="9" fill="#2E8B47" opacity=".18"/>
    <path d="M54 76c4-6 10-6 12 0" stroke="#2E8B47" stroke-width="2.4" fill="none"/>`),
  cafe: P120(`<rect x="36" y="30" width="48" height="64" rx="9" fill="#5B3A21"/>
    <rect x="40" y="22" width="40" height="10" rx="4" fill="#3E2817"/>
    <rect x="36" y="50" width="48" height="28" fill="#7C4A2A"/>
    ${txt(60,64,'Café',13,'#FFE9D0')}
    ${txt(60,74,'tostado',8.4,'#E8C9A8',700)}
    <ellipse cx="60" cy="90" rx="14" ry="4" fill="#4A2F1B" opacity=".5"/>`),
  te: P120(`<rect x="36" y="30" width="48" height="62" rx="6" fill="#FFFFFF" stroke="#D8E2EE" stroke-width="2"/>
    <rect x="36" y="30" width="48" height="16" fill="#3FAE5A"/>
    ${txt(60,42,'Té',11,'#fff')}
    <rect x="36" y="74" width="48" height="18" fill="#E9F8EF"/>
    <path d="M46 83c4-5 8 4 12-1s8 2 12-2" stroke="#3FAE5A" stroke-width="2.4" fill="none"/>
    <circle cx="60" cy="60" r="8" fill="#DFF2E4"/>
    <path d="M57 60c2-4 5-4 6-1" stroke="#3FAE5A" stroke-width="2" fill="none"/>`),
  harina: P120(`<path d="M36 34 h48 l6 12 v44 a8 8 0 0 1-8 8 H38 a8 8 0 0 1-8-8 V46 z" fill="#F4F6FA" stroke="#C9D2E2" stroke-width="2"/>
    <rect x="30" y="52" width="60" height="20" fill="#8FB2DD"/>
    ${txt(60,66,'000',13,'#fff')}
    ${txt(60,84,'Harina',9.5,'#5A6C94',700)}
    <path d="M36 34 h48 l4 8 H32 z" fill="#DCE5F2"/>`),
  arroz: P120(`<path d="M38 30 h44 l6 12 v48 a8 8 0 0 1-8 8 H40 a8 8 0 0 1-8-8 V42 z" fill="#E2574C"/>
    <path d="M38 30 h44 l4 9 H34 z" fill="#C2433A"/>
    <circle cx="60" cy="62" r="13" fill="#FFD23C"/>
    <path d="M52 62c3-6 13-6 16 0-3 6-13 6-16 0z" fill="#E2574C"/>
    <path d="M60 56c2 4 2 8 0 12" stroke="#FFD23C" stroke-width="2" fill="none"/>
    ${txt(60,88,'Arroz',11,'#fff')}`),
  lentejas: P120(`<path d="M38 28 h44 l5 10 v50 a8 8 0 0 1-8 8 H41 a8 8 0 0 1-8-8 V38 z" fill="#274690"/>
    <rect x="33" y="50" width="54" height="18" fill="#F29B38"/>
    ${txt(60,63,'Lentejas',10.5,'#fff')}
    <g fill="#E8C9A8"><circle cx="50" cy="79" r="2.4"/><circle cx="57" cy="83" r="2.4"/><circle cx="65" cy="78" r="2.4"/><circle cx="71" cy="83" r="2.4"/></g>
    ${txt(60,42,'Arcor',10,'#9CC4F0',700)}`),
  tomate: P120(`<rect x="38" y="34" width="44" height="56" rx="6" fill="#D8352C"/>
    <rect x="38" y="34" width="44" height="10" fill="#B52A22"/>
    <rect x="38" y="80" width="44" height="10" fill="#B52A22"/>
    <ellipse cx="60" cy="60" rx="15" ry="11" fill="#E95A50"/>
    <path d="M54 52c2-4 10-4 12 0" stroke="#FFD23C" stroke-width="2.4" fill="none"/>
    ${txt(60,65,'Tomate',8.4,'#fff')}
    ${txt(60,90,'en lata',8.4,'#FFD9D6',700)}`),
  atun: P120(`<rect x="38" y="38" width="44" height="48" rx="6" fill="#C7D0DC"/>
    <ellipse cx="60" cy="38" rx="22" ry="6" fill="#E8EEF5" stroke="#A9B6C8" stroke-width="1.6"/>
    <rect x="38" y="50" width="44" height="26" fill="#FFFFFF"/>
    <rect x="38" y="50" width="44" height="7" fill="#D8352C"/>
    ${txt(60,66,'Atún',11,'#D8352C')}
    ${txt(60,73,'en lata',7.6,'#5A6C94',700)}
    <path d="M50 60c3-2 7-2 10 0s7 2 10 0" stroke="#C7D0DC" stroke-width="1.6" fill="none" opacity="0"/>`),
  aceite: P120(`<path d="M50 30 h20 v8 c0 4 6 6 6 12 v44 a8 8 0 0 1-8 8 H52 a8 8 0 0 1-8-8 V50 c0-6 6-8 6-12 z" fill="#F5C63C" stroke="#E0A81F" stroke-width="2"/>
    <rect x="44" y="58" width="32" height="24" fill="#2E8B47"/>
    ${txt(60,70,'Aceite',10.5,'#fff')}
    ${txt(60,79,'oliva',8,'#DFF2E4',700)}
    <rect x="52" y="22" width="16" height="9" rx="2.6" fill="#2E8B47"/>
    <path d="M56 44c4 2 8 2 10-1" stroke="#B98A14" stroke-width="2" fill="none"/>`),
  sal: P120(`<rect x="36" y="34" width="48" height="58" rx="6" fill="#FFFFFF" stroke="#D5DEEC" stroke-width="2"/>
    <rect x="36" y="34" width="48" height="14" fill="#2F7FC4"/>
    ${txt(60,45,'SAL',10.5,'#fff')}
    <circle cx="60" cy="70" r="12" fill="#EAF3FF"/>
    <path d="M60 62v14 M53 68h14 M60 62c-3 3-3 8 0 11 M60 62c3 3 3 8 0 11" stroke="#2F7FC4" stroke-width="2.2" fill="none"/>`),
  panales: P120(`<rect x="30" y="44" width="60" height="44" rx="9" fill="#3FBFB2"/>
    <rect x="30" y="44" width="60" height="12" rx="6" fill="#2E9E93"/>
    <path d="M48 74c0-8 6-12 12-12s12 4 12 12c0 6-5 10-12 10s-12-4-12-10z" fill="#FFF"/>
    <path d="M56 72c2-3 5-3 6 0 M64 72c2-3 5-3 6 0" stroke="#2E9E93" stroke-width="2" fill="none"/>
    <circle cx="72" cy="62" r="7" fill="#FF8FB1"/>
    ${txt(48,60,'Pañales',9,'#fff')}`),
  alimento: P120(`<path d="M40 28 h40 l6 12 v46 a8 8 0 0 1-8 8 H42 a8 8 0 0 1-8-8 V40 z" fill="#E2574C"/>
    <path d="M40 28 h40 l5 10 H35 z" fill="#C2433A"/>
    <rect x="34" y="52" width="52" height="16" fill="#FFD23C"/>
    ${txt(60,64,'Mascotas',10.5,'#C2433A')}
    <circle cx="60" cy="84" r="11" fill="#FFF"/>
    <path d="M53 80c-1-4 2-7 4-4 M67 80c1-4-2-7-4-4" stroke="#E2574C" stroke-width="2.4" fill="none"/>
    <circle cx="56.5" cy="83" r="1.4" fill="#333"/><circle cx="63.5" cy="83" r="1.4" fill="#333"/>
    <path d="M58 88c1.5 1.6 2.5 1.6 4 0" stroke="#333" stroke-width="1.4" fill="none"/>`),
  papel: P120(`<g>
    <ellipse cx="46" cy="56" rx="10" ry="12" fill="#FFFFFF" stroke="#C9D2E2" stroke-width="2"/>
    <ellipse cx="46" cy="68" rx="10" ry="12" fill="#FFFFFF" stroke="#C9D2E2" stroke-width="2"/>
    <ellipse cx="74" cy="56" rx="10" ry="12" fill="#FFFFFF" stroke="#C9D2E2" stroke-width="2"/>
    <ellipse cx="74" cy="68" rx="10" ry="12" fill="#FFFFFF" stroke="#C9D2E2" stroke-width="2"/>
    <ellipse cx="46" cy="56" rx="4.5" ry="5.5" fill="#EDF1F8"/><ellipse cx="74" cy="56" rx="4.5" ry="5.5" fill="#EDF1F8"/>
    <ellipse cx="46" cy="68" rx="4.5" ry="5.5" fill="#EDF1F8"/><ellipse cx="74" cy="68" rx="4.5" ry="5.5" fill="#EDF1F8"/>
    <rect x="38" y="76" width="44" height="18" rx="6" fill="#2F7FC4"/>
    ${txt(60,89,'Papel',10.5,'#fff')}
  </g>`),
  /* store banner art */
  almacen: P120(`<rect x="22" y="46" width="20" height="48" rx="6" fill="#F5C63C" stroke="#E0A81F" stroke-width="1.6"/>
    <rect x="22" y="60" width="20" height="12" fill="#2E8B47"/><rect x="26" y="40" width="12" height="8" rx="2" fill="#2E8B47"/>
    <rect x="46" y="56" width="24" height="38" rx="5" fill="#E3342F"/><ellipse cx="58" cy="56" rx="12" ry="4.5" fill="#B52A22"/><rect x="46" y="68" width="24" height="12" fill="#fff"/>
    <path d="M48 74c4-4 8 4 12 0s8 4 10 0" stroke="#E3342F" stroke-width="2" fill="none"/>
    <rect x="74" y="50" width="22" height="44" rx="6" fill="#FFD23C"/><rect x="74" y="64" width="22" height="12" fill="#E23B32"/><rect x="78" y="44" width="14" height="8" rx="2" fill="#E8A50E"/>
    <rect x="30" y="94" width="64" height="4" rx="2" fill="#DCE3EF"/>`)
};

/* ---------- category illustrations ---------- */
const CATS = {
  almacen: PRODUCTS.almacen,
  bebidas: P120(`<rect x="26" y="32" width="20" height="56" rx="9" fill="#DFF0FF" stroke="#BBDFFC" stroke-width="2"/><rect x="26" y="52" width="20" height="16" fill="#2F8FE0"/><rect x="31" y="25" width="10" height="8" rx="2.4" fill="#1470FF"/>
    <rect x="52" y="40" width="22" height="48" rx="6" fill="#E3342F"/><rect x="52" y="56" width="22" height="13" fill="#fff"/><path d="M54 62.5c4 4 10-4 18 0" stroke="#E3342F" stroke-width="2.2" fill="none"/>
    <rect x="78" y="40" width="20" height="48" rx="6" fill="#3FAE5A"/><rect x="78" y="56" width="20" height="13" fill="#E9FBEE"/>`),
  panaderia: P120(`<path d="M24 56c0-10 10-16 24-16s24 6 24 16c0 5-4 8-9 8H33c-5 0-9-3-9-8z" fill="#E8B96B"/><path d="M38 46c2-3 6-3 8 0 M52 44c2-3 6-3 8 0" stroke="#B07E35" stroke-width="2" fill="none"/>
    <rect x="58" y="62" width="40" height="30" rx="4" fill="#FFF" stroke="#E4C896" stroke-width="2"/><circle cx="70" cy="74" r="3.4" fill="#D9A85F"/><circle cx="80" cy="80" r="3.4" fill="#D9A85F"/><circle cx="90" cy="73" r="3.4" fill="#D9A85F"/>
    <rect x="58" y="62" width="40" height="8" fill="#5FB3E0"/>`),
  limpieza: P120(`<rect x="28" y="44" width="20" height="46" rx="6" fill="#5FB3E0"/><rect x="32" y="34" width="12" height="10" rx="2" fill="#3D8BBF"/><path d="M44 40 l8 -6" stroke="#3D8BBF" stroke-width="3" stroke-linecap="round"/>
    <rect x="54" y="38" width="24" height="52" rx="8" fill="#3FAE5A"/><rect x="54" y="54" width="24" height="16" fill="#E9FBEE"/><rect x="60" y="30" width="12" height="8" rx="2.4" fill="#2E8B47"/>
    <g><circle cx="90" cy="66" r="11" fill="#FFF" stroke="#C9D2E2" stroke-width="2"/><circle cx="90" cy="66" r="4" fill="#EDF1F8"/><circle cx="90" cy="80" r="11" fill="#FFF" stroke="#C9D2E2" stroke-width="2"/><circle cx="90" cy="80" r="4" fill="#EDF1F8"/></g>`),
  farmacia: P120(`<rect x="26" y="46" width="30" height="44" rx="7" fill="#FFFFFF" stroke="#C9D2E2" stroke-width="2"/><rect x="26" y="46" width="30" height="12" fill="#3FAE5A"/>
    <rect x="38" y="62" width="6" height="16" fill="#3FAE5A"/><rect x="33" y="67" width="16" height="6" fill="#3FAE5A"/>
    <g transform="rotate(-18 76 60)"><rect x="58" y="42" width="36" height="22" rx="5" fill="#EAF3FF" stroke="#B9D4F5" stroke-width="2"/><circle cx="67" cy="53" r="5" fill="#E3342F"/><circle cx="81" cy="53" r="5" fill="#5FB3E0"/></g>
    <circle cx="78" cy="78" r="6" fill="#FFB63C"/><circle cx="88" cy="84" r="5" fill="#FF8FB1"/>`),
  mascotas: P120(`<path d="M32 34 h34 l4 8 v40 a7 7 0 0 1-7 7 H35 a7 7 0 0 1-7-7 V42 z" fill="#8C5A2E"/>
    <path d="M32 34 h34 l3.5 7 H28.5 z" fill="#6E4520"/>
    <circle cx="49" cy="62" r="12" fill="#FFD9B0"/>
    <path d="M42 58c-1-5 3-9 5-5 M56 58c1-5-3-9-5-5 M44 66c1.6 2.4 6.4 2.4 8 0" stroke="#8C5A2E" stroke-width="2.4" fill="none"/>
    <circle cx="45.5" cy="61" r="1.5" fill="#4A2F1B"/><circle cx="52.5" cy="61" r="1.5" fill="#4A2F1B"/>
    <g><ellipse cx="84" cy="84" rx="18" ry="8" fill="#5A6C94"/><ellipse cx="84" cy="80" rx="15" ry="6.5" fill="#3A466E"/><circle cx="78" cy="78" r="2" fill="#FFD23C"/><circle cx="86" cy="79" r="2" fill="#FFD23C"/><circle cx="90" cy="82" r="2" fill="#FFD23C"/></g>`),
  perfumeria: P120(`<rect x="30" y="42" width="20" height="50" rx="7" fill="#2F7FC4"/><rect x="35" y="34" width="10" height="9" rx="2" fill="#1B5C96"/><path d="M36 66h8M36 72h8" stroke="#DCEFFF" stroke-width="2" stroke-linecap="round"/>
    <g transform="rotate(-24 70 70)"><rect x="52" y="60" width="38" height="14" rx="7" fill="#FFFFFF" stroke="#C9D2E2" stroke-width="2"/><rect x="52" y="60" width="10" height="14" rx="5" fill="#E2574C"/><circle cx="76" cy="67" r="3" fill="#E2574C"/></g>
    <g><rect x="80" y="36" width="6" height="52" rx="3" fill="#5FB3E0"/><g fill="#FFF" stroke="#C9D2E2"><rect x="79.6" y="36" width="6.8" height="10" rx="2"/></g><path d="M80 36v-4h6v4" fill="none" stroke="#5FB3E0" stroke-width="2.4"/></g>`),
  libreria: P120(`<rect x="28" y="40" width="42" height="54" rx="5" fill="#2F6FD0"/><rect x="28" y="40" width="8" height="54" fill="#1B4E9E"/>
    <rect x="42" y="52" width="22" height="3.4" rx="1.7" fill="#DCEFFF"/><rect x="42" y="60" width="22" height="3.4" rx="1.7" fill="#DCEFFF"/><rect x="42" y="68" width="16" height="3.4" rx="1.7" fill="#DCEFFF"/>
    <g transform="rotate(14 84 66)"><rect x="70" y="56" width="30" height="9" rx="4.5" fill="#FF8FB1"/><rect x="96" y="56" width="7" height="9" rx="3" fill="#E2579B"/></g>
    <g transform="rotate(-8 84 82)"><rect x="70" y="76" width="30" height="9" rx="4.5" fill="#FFD23C"/><rect x="96" y="76" width="7" height="9" rx="3" fill="#E0A81F"/></g>`),
  tecnologia: P120(`<rect x="30" y="48" width="56" height="30" rx="8" fill="#2A3560"/><rect x="30" y="48" width="56" height="30" rx="8" fill="none" stroke="#1B2444" stroke-width="2"/>
    <rect x="36" y="56" width="22" height="14" rx="3" fill="#5FB3E0"/><circle cx="76" cy="63" r="3" fill="#3FAE5A"/>
    <path d="M38 88c14 10 34 10 44 0" stroke="#C9D2E2" stroke-width="4" fill="none" stroke-linecap="round"/>
    <rect x="30" y="84" width="10" height="10" rx="2.6" fill="#8FB2DD"/><rect x="84" y="84" width="10" height="10" rx="2.6" fill="#8FB2DD"/>`),
  hogar: P120(`<path d="M44 52c0-11 7-18 16-18s16 7 16 18c0 8-5 11-8 16a10 10 0 0 1-16 0c-3-5-8-8-8-16z" fill="#FFF3C4" stroke="#E8C95A" stroke-width="2.4"/>
    <path d="M52 44c2-3 5-3 7 0 M60 44c2-3 5-3 7 0 M56 52v8 M52 56l8 4 8-4" stroke="#C9A227" stroke-width="2" fill="none"/>
    <rect x="46" y="66" width="12" height="8" rx="2" fill="#B8C2CF"/>
    <g transform="rotate(38 84 62)"><rect x="80" y="34" width="7" height="34" rx="3" fill="#FFB63C"/><rect x="77" y="66" width="13" height="16" rx="4" fill="#2A3560"/></g>
    <circle cx="36" cy="86" r="8" fill="#C9D2E2"/><rect x="33" y="88" width="6" height="6" fill="#8FB2DD"/>`),
  automotor: P120(`<path d="M34 34 h30 v10 c0 4 5 6 5 11 v41 a7 7 0 0 1-7 7 H36 a7 7 0 0 1-7-7 V45 c0-5 5-7 5-11 z" fill="#2A3560"/>
    <rect x="40" y="56" width="22" height="20" rx="3" fill="#E3342F"/>
    ${txt(51,70,'Aceite',6.6,'#fff')}
    <rect x="40" y="27" width="14" height="8" rx="2.4" fill="#1B2444"/>
    <g stroke="#8FB2DD" stroke-width="5" fill="none" stroke-linecap="round"><path d="M76 44a10 10 0 0 1 14-9l4 4-6 6 4 4a10 10 0 0 1-14 9z"/><path d="M84 52 L98 88"/></g>
    <circle cx="98" cy="90" r="4" fill="#8FB2DD"/>`),
  otros: P120(`<path d="M28 34h10l8 38h34l8-28H42" fill="none" stroke="#0A66FF" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
    <circle cx="52" cy="84" r="6" fill="#0A66FF"/><circle cx="80" cy="84" r="6" fill="#0A66FF"/>`)
};

/* ---------- brand logos ---------- */
function google(){
  return `<svg width="22" height="22" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.2C12.4 13.4 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.7 6C44.1 38 46.5 31.8 46.5 24.5z"/><path fill="#FBBC05" d="M10.5 28.6c-.5-1.5-.8-3-.8-4.6s.3-3.1.8-4.6l-7.9-6.2C.9 16.5 0 20.1 0 24s.9 7.5 2.6 10.8l7.9-6.2z"/><path fill="#34A853" d="M24 48c6.3 0 11.6-2.1 15.6-5.8l-7.7-6c-2.1 1.5-4.9 2.3-7.9 2.3-6.3 0-11.6-3.9-13.5-9.4l-7.9 6.2C6.5 42.6 14.6 48 24 48z"/></svg>`;
}
function apple(){
  return `<svg width="20" height="22" viewBox="0 0 24 28" fill="#111"><path d="M16.4 14.6c0-3.2 2.6-4.8 2.7-4.9-1.5-2.2-3.8-2.5-4.6-2.5-2-.2-3.8 1.1-4.8 1.1-1 0-2.6-1.1-4.2-1.1-2.2 0-4.2 1.3-5.3 3.2-2.3 3.9-.6 9.7 1.6 12.9 1.1 1.6 2.4 3.3 4.1 3.2 1.6-.1 2.3-1.1 4.2-1.1s2.5 1.1 4.2 1c1.8 0 2.9-1.6 4-3.2 1.3-1.8 1.8-3.5 1.8-3.6-.1 0-3.6-1.4-3.7-5.6zM13 5.1c.9-1.1 1.5-2.6 1.3-4.1-1.3.1-2.9.9-3.8 2-.8.9-1.6 2.5-1.4 4 1.5.1 3-.8 3.9-1.9z"/></svg>`;
}
function mpLogo(sz){
  sz = sz || 30;
  return `<svg class="mp-logo" width="${sz}" height="${sz}" viewBox="0 0 48 48">
    <circle cx="24" cy="24" r="23" fill="#00AEEF"/>
    <g fill="#FFFFFF">
      <path d="M11 26.5c2.6-1.4 5-3.4 7-5.8l4.2-4.9c.5-.6 1.5-.6 2 0l.9 1c.4.5.4 1.2 0 1.7l-3.2 3.8 2.5-1.9c.5-.4 1.3-.3 1.7.2l.8 1c.4.5.4 1.3-.2 1.7l-4.6 3.6 2.3-1.2c.5-.3 1.2-.1 1.5.4l.7 1.1c.3.5.2 1.2-.3 1.5l-2.7 1.7c2.4-.4 4.6-1.5 6.4-3.2 3.4-3.2 4.7-7.7 3.9-11.9l-6.5 2.9c-.5.2-1 .1-1.4-.3l-1.1-1.1c-.4-.4-.4-1.1 0-1.5l4.2-4.1c.4-.4 1-.5 1.6-.2l2.3 1.2c1.1-.6 2.4-1 3.7-1.1 1.7-.2 3.4.2 4.8 1.1-2.2 7.5-6.4 12.9-12.9 15.4-5.2 2-10.6 1.3-15.1-1.7l3.4-3.9c.4-.5 1-.6 1.6-.3z" opacity=".0"/>
      <path d="M13.5 27.2l7.6-8.4c.6-.6 1.6-.6 2.2 0l1.5 1.5c.5.5.5 1.3 0 1.8l-5 5.5c1.5.3 3.2.1 4.7-.6l1.6-.8c.6-.3 1.3-.2 1.7.3l.8 1c.5.6.3 1.5-.3 1.9l-3.6 2c3-1.2 5.7-3.2 7.7-5.8 2.5-3.3 3.9-7.3 3.9-11.3-1.3-.6-2.9-.8-4.4-.5-2 .4-3.7 1.4-5 2.9l-2.2 2.4c-.5.6-1.4.6-2 0l-1.4-1.4c-.5-.5-.5-1.4.1-1.9l2.6-2.3c-1.4.3-2.7 1-3.7 2.1l-3 3.3c-.5.6-1.4.6-2 .1l-1.3-1.2c-.5-.5-.5-1.3 0-1.8l1-1c-.2 2.3-.8 4.5-1.9 6.6-1.3 2.6-3.2 4.8-5.4 6.6l2.4-1.7c.4-.3 1-.3 1.5-.2z" opacity="0"/>
      <g>
        <path d="M12 24.2c1.9-1.6 3.6-3.5 5-5.6l2.3-3.1c.5-.6 1.4-.6 1.9 0l1 1c.4.4.4 1.1.1 1.6l-2.9 3.7 2.2-1.6c.5-.4 1.2-.3 1.6.2l.7.9c.4.5.3 1.2-.2 1.6l-4 3.1 1.9-1c.5-.3 1.1-.1 1.4.4l.6.9c.3.5.2 1.1-.3 1.4l-2.3 1.4c2-.3 3.9-1.3 5.4-2.8 3-3 4.2-7.1 3.4-11l-5.5 2.5c-.4.2-.9.1-1.2-.2l-.9-1c-.4-.4-.4-1 0-1.4l3.5-3.4c.4-.4 1-.4 1.4-.2l1.9 1c.9-.5 2-.8 3.1-.9 1.4-.2 2.9.1 4.1.9-1.9 6.3-5.4 10.9-10.9 13-4.4 1.7-9 1.1-12.8-1.4l2.9-3.3c.4-.4 1-.5 1.4-.3z" transform="translate(-1.2 1.2) scale(.98)"/>
      </g>
    </g>
  </svg>`;
}

/* ---------- small ui illustrations ---------- */
function emptyIll(kind){
  if(kind==='orders') return `<svg width="74" height="74" viewBox="0 0 74 74" fill="none">
    <rect x="16" y="20" width="42" height="44" rx="7" fill="#DCEBFD"/><rect x="24" y="14" width="26" height="12" rx="4" fill="#B9D4F5"/>
    <rect x="24" y="34" width="26" height="4.5" rx="2.2" fill="#8FB2DD"/><rect x="24" y="43" width="18" height="4.5" rx="2.2" fill="#B9D4F5"/>
    <circle cx="52" cy="52" r="14" fill="#0A66FF"/><path d="M46 52l4.5 4.5L60 47" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  if(kind==='favs') return `<svg width="74" height="74" viewBox="0 0 74 74" fill="none">
    <path d="M37 62S12 46.5 12 30.5C12 20 20 13.5 28 13.5c4 0 7.5 2 9 4.6 1.5-2.6 5-4.6 9-4.6 8 0 16 6.5 16 17C62 46.5 37 62 37 62z" fill="#DCEBFD"/>
    <circle cx="54" cy="24" r="9" fill="#0A66FF" opacity=".15"/></svg>`;
  return `<svg width="74" height="74" viewBox="0 0 74 74" fill="none">
    <circle cx="37" cy="37" r="26" fill="#DCEBFD"/>${I('search',40,'')}
    </svg>`;
}

A.pMark = pMark; A.logo = logo; A.townHeader = townHeader; A.homeHero = homeHero;
A.mapBase = mapBase; A.riderAva = riderAva; A.riderShop = riderShop; A.PRODUCTS = PRODUCTS;
A.CATS = CATS; A.google = google; A.apple = apple; A.mpLogo = mpLogo; A.tower = tower; A.emptyIll = emptyIll;
window.Art = A;
})();
